 _    _       _    _____            _             _       
| |  | |     | |  / ____|          | |           | |      
| |__| | ___ | |_| |     ___  _ __ | |_ ___ _ __ | |_ ___ 
|  __  |/ _ \| __| |    / _ \| '_ \| __/ _ \ '_ \| __/ __|
| |  | | (_) | |_| |___| (_) | | | | ||  __/ | | | |_\__ \
|_|  |_|\___/ \__|\_____\___/|_| |_|\__\___|_| |_|\__|___/

-A Kerbal Space Program mod created by Sequinox and Joco223-                                                           
----------------------------------------------------
Hey! There's some pretty neat information here, and it's all written in plain English! So have a look if you fancy!
----------------------------------------------------
This mod is disturbited under the CC-BY-NC-SA license! 
What does this mean? Well, it pretty much means that you can redistribute our mod so long as you give credit to us, make clear any changes you make, 
and you don't do it for money! Additionaly, you must also use the same license as we do.
----------------------------------------------------
MINI-AVC INFO
-
http://forum.kerbalspaceprogram.com/threads/79745
Alright, this is pretty important. So go ahead and have a sit down. Let's talk about it.

The KSP community add-on guidelines state that we can't contact another network or computer system without clearly stating what it does, so here we go.
Mini-AVC is a plugin that the KSP addon version checker addon uses. We have put this in our mod so you, the player, can keep up with the versions. When you boot up the game
there will be a windows asking if you would like to opt-in to addon version checking. Data is only read from the internet and no personal information is sent.
-




